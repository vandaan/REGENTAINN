<?php
session_start();

?>
<?php
 require('admin/inc/db_config.php');
 require('admin/inc/essentials.php');
 
 
			$contact_q = "SELECT * FROM `contact_details` WHERE `sr_no`=?";
			$settings_q = "SELECT * FROM `settings` WHERE `sr_no`=?";
			$values = [1];
			$contact_r = mysqli_fetch_assoc(select($contact_q,$values,'i'));
			$settings_r = mysqli_fetch_assoc(select($settings_q,$values,'i'));

if ($settings_r['shutdown']==true) {
    echo <<<alertbar
    <div class='bg-danger text-center p-2 fw-bold'>
    Bookings are temporarily closed!
    </div>
alertbar;
}
		?> 
 <div class="container-fluid bg-dark px-0">
             <div class="row gx-0">
                <div class="col-lg-3 bg-dark d-none d-lg-block">
                    <a href="index.php" class="navbar-brand w-100 h-100 m-0 p-0 d-flex align-items-center justify-content-center">
                        <h1 class="m-0 text-primary text-uppercase"><?php  echo $settings_r['site_title']?></h1>
                    </a>
                </div>
                <div class="col-lg-9">
                    <div class="row gx-0 bg-white d-none d-lg-flex">
                        <div class="col-lg-7 px-5 text-start">
                            <div class="h-100 d-inline-flex align-items-center py-2 me-4">
                                <i class="fa fa-envelope text-primary me-2"></i>
                                <a class="me-3 d-inline-block text-decoration-none text-dark" href="<?php echo $contact_r['email'] ?>"> <?php echo $contact_r['email'] ?></a>
                            </div>
                            
                        </div>
                        <div class="col-lg-5 px-5 text-end">
                            <div class="d-inline-flex align-items-center py-2">
                                <a class="me-3" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="me-3" href=""><i class="fab fa-twitter"></i></a>
                                <a class="me-3" href=""><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                    <nav id="nav-bar" class="navbar navbar-expand-lg bg-dark navbar-dark p-3 p-lg-0">
                        <a href="index.php" class="navbar-brand d-block d-lg-none">
                            <h1 class="m-0 text-primary text-uppercase">Regenta <sub>Inn</sub></h1>
                        </a>
                        <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                            <div class="navbar-nav mr-auto py-0">
                                <a href="index.php" class="nav-item nav-link">Home</a>
                                <a href="about.php" class="nav-item nav-link">About</a>
                                <a href="service.php" class="nav-item nav-link">Services</a>
                                <a href="room.php" class="nav-item nav-link">Rooms</a>
                                <a href="contact.php" class="nav-item nav-link">Contact</a>
                            </div>
						


						<div class="d-flex">
							<?php
							if (isset($_SESSION['login']) && $_SESSION['login'] == true) {
								echo <<<data
								<div class="btn-group">
									<button type="button" class="btn btn-secondary dropdown-toggle shadow-none" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false">
										$_SESSION[uName]
									</button>
									<ul class="dropdown-menu dropdown-menu-lg-end">
										<li><a class="dropdown-item" href="profile.php">Profile</a></li>
										<li><a class="dropdown-item" href="bookings.php">Bookings</a></li>
										<li>
											<form method="post" action="logout.php">
												<button type="submit" name="logout" class="dropdown-item">Logout</button>
											</form>
										</li>
									</ul>
								</div>
								data;
							} else {
								echo <<<data
								<button type="button" class="btn btn-outline-light me-lg-3 me-2 shadow-none" data-bs-toggle="modal" data-bs-target="#loginmodal">
									Login
								</button>
								<button type="button" class="btn btn-outline-light shadow-none" data-bs-toggle="modal" data-bs-target="#registermodal">
									Register
								</button>
								data;
							}
							?>
						</div>

                        </div>
                    </nav>
                

                    <div class="modal fade" id="loginmodal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="login_register.php">
                <div class="modal-header">
                    <h5 class="modal-title d-flex align-items-center">
                        <i class="bi bi-person-circle fs-3 me-2"></i>
                        User Login
                    </h5>
                    <button type="reset" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Email address</label>
                        <input type="text" name="email_or_phone"  required class="form-control shadow-none">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="pass" required class="form-control shadow-none">
                    </div>
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <button type="submit" name="login" class="btn btn-dark shadow-none">LOGIN</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>


                      <div class="modal fade" id="registermodal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                          <div class="modal-content">
                            <form method="POST" action="login_register.php" name="registration-form">
                             <div class="modal-header">
                              <h5 class="modal-title d-flex align-items-center">
                                <i class="bi bi-person-lines-fill fs-3 me-2"></i>

                                User Registration</h5>
                              <button type="reset" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-md-6 ps-0 mb-3">
                                            <label class="form-label">Name</label>
                                            <input type="text" name="name"class="form-control shadow-none " required> 
                                            
                                        </div>
                                        <div class="col-md-6 p-0 MB-3">
                                            <label class="form-label">Email</label>
                                            <input type="email" name="email"class="form-control shadow-none"required > 
                                            
                                        </div>
                                        <div class="col-md-6 ps-0 mb-3">
                                            <label class="form-label">Phone Number</label>
                                            <input type="number" name="phonenum"class="form-control shadow-none" required> 
                                            
                                        </div>
                                        <div class="col-md-6 p-0 mb-3">
											<label class="form-label">Gender</label>
											<select name="gender" class="form-select shadow-none" required>
											<option value="" disabled selected>Select Gender</option>
											<option value="male">Male</option>
											<option value="female">Female</option>
											<option value="other">Other</option>
											</select>
										</div>

                                        <div class="col-md-12 p-0 mb-3">
                                            <label class="form-label">Address</label>
                                            <textarea name="address" class="form-control shadow-none" rows="1" required></textarea>
                                        </div>
                                        <div class="col-md-6 ps-0 mb-3">
                                            <label class="form-label">Pincode</label>
                                            <input type="number" name="pincode"class="form-control shadow-none" required> 
                                            
                                        </div>
                                        <div class="col-md-6 p-0 mb-3">
                                            <label class="form-label">Date of birth</label>
                                            <input type="date" name="dob" class="form-control shadow-none" required> 
                                            
                                        </div>
                                        <div class="col-md-6 p-0 mb-3">
                                            <label class="form-label">Password</label>
                                            <input type="password" name="pass" class="form-control shadow-none" required> 
                                            
                                        </div>
                                        <div class="col-md-6 p-0 mb-3">
                                            <label class="form-label">Confirm Password</label>
                                            <input type="password" name= "cpass"class="form-control shadow-none" required> 
                                            
                                        </div>
                                       
                                    </div>
                                </div>
                                <div class="text-center MY-1">
                                    <button type="submit" name="register" class="btn btn-dark shadow-none">REGISTER</button>
                                </div>
                                                           
                            </div>
                            
                            </form>
                          </div>
                        </div>
                      </div>

                      
                  </div>
            </div>
        </div>
        <!-- Header End -->
		
		<script>
 

    document.querySelector('form').addEventListener('submit', function (event) {
        const form = event.target;
        const inputField = form.querySelector('input[name="email_or_phone"]');
        const inputValue = inputField.value.trim();

        if (!isValidInput(inputValue)) {
            event.preventDefault(); // Prevent form submission
        }
    });



    document.querySelector('form').addEventListener('submit', function (event) {
        const form = event.target;
        const inputField = form.querySelector('input[name="email_or_phone"]');
        const inputValue = inputField.value.trim();

        // Check if the form is the logout form, and skip validation if it is
        if (form.getAttribute('name') !== 'logoutForm' && !isValidInput(inputValue)) {
            alert('Please enter a valid email address or phone number.');
            event.preventDefault(); // Prevent form submission
        }
    });
</script>

