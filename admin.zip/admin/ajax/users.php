<?php

	require('../inc/db_config.php');   
	require('../inc/essentials.php');
	adminLogin();
	
	
	if (isset($_POST['get_users'])) {
    $res = selectAll('registration');
    $i = 1;

    $data = "";

    while ($row = mysqli_fetch_assoc($res)) {
		
		//delete button
		$del_btn="<button type='button' onclick='remove_user($row[id])' class='btn btn-danger shadow-none  btn-sm'>
			  <i class='bi bi-trash'></i>
			  </button>";
		
		
		
        // Define a variable to hold the status button HTML
        $status= "<button onclick='toggle_status($row[id],0)' class='btn btn-dark btn-sm shadow-none'>Active</button>";

        // Check if the status is 1 (Active)
        if (!$row['status']) {
            $status = "<button onclick='toggle_status($row[id],1)' class='btn btn-danger btn-sm shadow-none'>Inactive</button>";
			
        }
		else{
			$del_btn="";
		}
		
		$date=date("d-m-Y | H:m:s",strtotime($row['datentime']));

        $data .= "
        <tr>
            <td>$i</td>
            <td>$row[name]</td>
            <td>$row[email]</td>
            <td>$row[phonenum]</td>
            <td>$row[address] | $row[pincode]</td>
            <td>$row[dob]</td>
            <td>$status</td>
            <td>$date</td>
            <td>$del_btn</td>
			
        </tr>
        ";
        $i++;
    }
    echo $data;
}

	if (isset($_POST['toggle_status'])) {
    $frm_data = filteration($_POST);

    // Log the received values
    error_log("Received toggle_status: " . $frm_data['toggle_status']);
    error_log("Received value: " . $frm_data['value']);

    $q = "UPDATE `registration` SET `status`=? WHERE `id`=?";
    $v = [$frm_data['value'], $frm_data['toggle_status']];

    // Log the SQL query being executed
    error_log("SQL Query: " . $q);

    if (update($q, $v, 'ii')) {
        echo 1;
    } else {
        // Log an error message if the update fails
        error_log("Update failed");
        echo 0;
    }
}

	
	if(isset($_POST['remove_user']))
	{
		$frm_data = filteration($_POST);
		
		
		 $res = delete("DELETE FROM `registration` WHERE `id`=?", [$frm_data['user_id']], 'i');
		
		if ($res) {
    echo 1;
} else {
    echo 0; 
}

		
	}
	
	if (isset($_POST['search_user'])) {
    
	$frm_data=filteration($_POST);
	
	$query="SELECT * FROM `registration` WHERE `name` LIKE ?";
	
	$res = select($query,["%$frm_data[name]%"],'s');
    $i = 1;

    $data = "";

    while ($row = mysqli_fetch_assoc($res)) {
		
		//delete button
		$del_btn="<button type='button' onclick='remove_user($row[id])' class='btn btn-danger shadow-none  btn-sm'>
			  <i class='bi bi-trash'></i>
			  </button>";
		
		
		
        // Define a variable to hold the status button HTML
        $status= "<button onclick='toggle_status($row[id],0)' class='btn btn-dark btn-sm shadow-none'>Active</button>";

        // Check if the status is 1 (Active)
        if (!$row['status']) {
            $status = "<button onclick='toggle_status($row[id],1)' class='btn btn-danger btn-sm shadow-none'>Inactive</button>";
			
        }
		else{
			$del_btn="";
		}
		
		$date=date("d-m-Y | H:m:s",strtotime($row['datentime']));

        $data .= "
        <tr>
            <td>$i</td>
            <td>$row[name]</td>
            <td>$row[email]</td>
            <td>$row[phonenum]</td>
            <td>$row[address] | $row[pincode]</td>
            <td>$row[dob]</td>
            <td>$status</td>
            <td>$date</td>
            <td>$del_btn</td>
			
        </tr>
        ";
        $i++;
    }
    echo $data;
}	
	
	
?>


