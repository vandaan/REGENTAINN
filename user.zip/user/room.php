<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Regenta Inn Hotel</title>
<meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

         <?php require('inc/header.php') ?>
																					
        <!-- Page Header Start -->
        <div class="container-fluid page-header mb-5 p-0" style="background-image: url(images/carousel/IMG_91648.jpg); max-width: 1500px;" >
            <div class="container-fluid page-header-inner py-5">
                <div class="container text-center pb-5">
                    <h1 class="display-3 text-white mb-3 animated slideInDown">Rooms</h1>
                    <nav aria-label="breadcrumb">
                       
                    </nav>
                </div>
            </div>
        </div>
        <!-- Page Header End -->


        <!-- Add the alert message here -->
<?php if (isset($_SESSION['alert_message'])): ?>
    <?php echo $_SESSION['alert_message']; ?>
    <?php unset($_SESSION['alert_message']); ?>
<?php endif; ?>

<!-- Your booking form and other content -->

       
		<!--filter start-->
        <div class="container-fluid">
			<div class="row">
				
			
					<!-- filter end-->
					
				<!--rooms start-->
				<div class="col-lg-10 col-md-13 px-3 ">
				<?php
				 
				 $room_res= select("SELECT * FROM `rooms` WHERE `status`=? AND `removed`=? ORDER BY `id`DESC",[1,0],'ii');
				 
				 while($room_data= mysqli_fetch_assoc($room_res))
				 {
					 //get features of Room
					 $fea_q = mysqli_query($con,"SELECT f.name FROM `features` f INNER JOIN `room_features` rfea ON f.id = rfea.features_id WHERE rfea.room_id= '$room_data[id]'");
					 
					 $features_data="";
					 while($fea_row = mysqli_fetch_assoc($fea_q))
					 {
					   $features_data.= "<span class='badge rounded-pill bg-light text-dark text-wrap me-1 mb-1'>
								$fea_row[name]
								</span>";
						
						
					 }
					 
					 //get feacility of Room
					 
					 $fac_q =mysqli_query($con,"SELECT f.name FROM `facilities` f INNER JOIN `room_facilities` rfac ON f.id=rfac.facilities_id WHERE rfac.room_id= '$room_data[id]'");
					 
					 $facilities_data="";
					 while($fac_row = mysqli_fetch_assoc($fac_q))
					 {
					   $facilities_data.= "<span class='badge rounded-pill bg-light text-dark text-wrap me-1 mb-1'>
								$fac_row[name]
								</span>";
						
					 }
					 
					  //get thumbnail of image
					  
					 $room_thumb = ROOMS_IMAGE_PATH."thumbnail.jpg";
					 $thumb_q = mysqli_query($con,"SELECT * FROM `room_images` WHERE `room_id`='$room_data[id]' AND `thumb`='1'");
					 
					 if(mysqli_num_rows($thumb_q)>0){
						$thumb_res = mysqli_fetch_assoc($thumb_q);
						$room_thumb=ROOMS_IMAGE_PATH.$thumb_res['image'];						
					 }
					 
					$book_btn = "";

					if (!$settings_r['shutdown']) {
						$login = 0;

						if (isset($_SESSION['login']) && $_SESSION['login'] == true) {
							$login = 1;
						}

						$book_btn = "<button class='btn btn-sm w-100 btn-dark rounded py-2 mb-2' onclick=\"checkLoginToBook($login, {$room_data['id']})\">Book Now</button>";
					}

					 //print room card
					 
					 echo<<<data
					 <div class="card mb-4 border-0 shadow">
					<div class="row g-0 p-3 align-items-center">
						<div class="col-md-5 mb-lg-0 mb-md-0 mb-3">
							<img src="$room_thumb" class="img-fluid rounded" >
						</div>
					<div class="col-md-5 px-lg-3 px-md-3 px-0">
						<h5 class="mb-3 p-4">$room_data[name]</h5>
							<div class="features mb-3">
							 <h6 class="mb-3">Features</h6>
								$features_data
						</div>
						<div class="facilities mb-3">
								<h6 class="mb-3">Facilities</h6>
								$facilities_data
						</div>
						<div class="guests mb-3">
							<h6 class="mb-1">Guests</h6>
							<span class="badge rounded-pill bg-light text-dark text-wrap">
							$room_data[adult] Adults
							</span><span class="badge rounded-pill bg-light text-dark text-wrap">
							 $room_data[children]Children
							</span>
						</div>
						
					</div>
						<div class=" col-md-2 mt-lg-0 mt-md-0 mt-4text-center">
							<h6 class="mb-4"> Rs.$room_data[price]/Night</h6>
							$book_btn
							<a href="room_details.php?id=$room_data[id]" class="btn btn-sm  w-100 btn-outline-dark rounded py-2 shadow-none" >More details</a>
						</div>
					</div>
				</div>
			data;
				 }
				
				?>
					
				</div>
			
	
		</div>
		</div>
		
			
		<!-- Room End -->
			
				

        

        <!-- Footer Start -->
        <?php require('inc/footer.php') ?>
        <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>