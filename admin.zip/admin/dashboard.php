<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Dashboard</title>
    <?php 
    require('inc/links.php');
    ?>
</head>
<body class="bg-light">
    <?php 
    require('inc/header.php');
	require('inc/db_config.php');
	
	$is_shutdown = mysqli_fetch_assoc(mysqli_query($con,"SELECT `shutdown` FROM `settings`"));
	
	$current_bookings = mysqli_fetch_assoc(mysqli_query($con,"SELECT COUNT(CASE WHEN arrival = 0 THEN 1 END) AS `new_bookings` FROM `booking_order`;"));
	
	$unread_queries = mysqli_fetch_assoc(mysqli_query($con,"SELECT COUNT(sr_no)AS `count`
	FROM `user_queries` WHERE `seen` = 0"));
	
	$current_users = mysqli_fetch_assoc(mysqli_query($con,"SELECT
    COUNT(id) AS `total`,
    SUM(CASE WHEN `status` = 1 THEN 1 ELSE 0 END) AS `active`,
    SUM(CASE WHEN `status` = 0 THEN 1 ELSE 0 END) AS `inactive`
FROM `registration`
"));
	
	    
    ?>
    <div class="container-fluid" id="main-content">
        <div class="row">
            <div class="col-lg-10 ms-auto p-2 overflow-hidden">
                <div class="content">
                    <div class="d-flex align-items-center justify-content-between mb-3"> <!-- Adjusted margin-bottom value -->
                        <h1 style="margin-top: 5px; ">DASHBOARD</h1> <!-- Removed margin-top -->
						<?php
						if($is_shutdown['shutdown']){
							echo<<<data
							<h6 class="badge bg-danger py-2 px-3 rounded">Shutdown mode is active!</h6>
							data;
						}?>
                        
                    </div>
                    <div class="row mb-1" style="margin-top: -110px; ">
                        <div class="col-md-3"> <!-- Reduced margin from mb-4 to mb-2 -->
                            <a href="new_bookings.php" class="text-decoration-none">
                                <div class="card text-center text-success p-3 ">
                                    <h6>New Bookings</h6>
                                    <h1 class="mt-2 mb-0"><?php echo $current_bookings['new_bookings'] ?></h1>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 "> <!-- Reduced margin from mb-4 to mb-2 -->
                            <a href="user_queries.php" class="text-decoration-none">
                                <div class="card text-center text-info p-3">
                                    <h6>User Queries</h6>
                                    <h1 class="mt-2 mb-0"><?php echo $unread_queries['count'] ?></h1>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="d-flex align-items-center justify-content-between" style="margin-top: -50px; "> <!-- Adjusted margin-bottom value -->
                        <h3 style="margin-top: 5px; ">Booking Analytics</h3> 
                        
                    </div>
					 <div class="row mb-1" style="margin-top: -110px; ">
                        <div class="col-md-3"> <!-- Reduced margin from mb-4 to mb-2 -->
                        
                                <div class="card text-center text-primary p-3 ">
                                    <h6>Total Bookings</h6>
                                    <h1 class="mt-2 mb-0" id="total_bookings">0</h1>
									
                                </div>
                           
                        </div>
                        <div class="col-md-3"> <!-- Reduced margin from mb-4 to mb-2 -->
                        
                                <div class="card text-center text-success p-3 ">
                                    <h6>Active Bookings</h6>
                                    <h1 class="mt-2 mb-0" id="active_bookings">0</h1>
								
                                </div>
								
                           
                        </div>
						
						
						
						 <div class="d-flex align-items-center justify-content-between" style="margin-top: -20px; "> <!-- Adjusted margin-bottom value -->
                        <h3 style="margin-top: 20px; ">User, Queries Analytics</h3> 
                        
                    </div>
						<div class="row mb-1" style="margin-top: -58px; ">
                        <div class="col-md-3"> <!-- Reduced margin from mb-4 to mb-2 -->
                        
                                <div class="card text-center text-success p-3 ">
                                    <h6>User Registration</h6>
                                    <h1 class="mt-2 mb-0" id="total_new_reg">0</h1>
									
                                </div>
                           
                        </div>
                        <div class="col-md-3"> <!-- Reduced margin from mb-4 to mb-2 -->
                        
                                <div class="card text-center text-success p-3 ">
                                    <h6>Queries</h6>
                                    <h1 class="mt-2 mb-0" id="total_queries">0</h1>
									
                                </div>
								
                           
                        </div>
						
						
						 <h3 style="margin-top: -10px; ">Users</h3> 
						  <div class="col-md-3"> <!-- Reduced margin from mb-4 to mb-2 -->
                        
                                <div class="card text-center text-info p-3" style="margin-top: -53px; ">
                                    <h6>Total</h6>
                                  <h1 class="mt-2 mb-0"><?php echo $current_users['total'] ?></h1>
									
                                </div>
                           
                        </div>
                        <div class="col-md-3"> <!-- Reduced margin from mb-4 to mb-2 -->
                        
                                <div class="card text-center text-success p-3 " style="margin-top: -53px; ">
                                    <h6>Active </h6>
                                    <h1 class="mt-2 mb-0"><?php echo $current_users['active'] ?></h1>
									
                                </div>
								
                           
                        </div>
						<div class="col-md-3"> <!-- Reduced margin from mb-4 to mb-2 -->
                        
                                <div class="card text-center text-warning p-3 " style="margin-top: -53px; ">
                                    <h6>Inactive</h6>
                                    <h1 class="mt-2 mb-0"><?php echo $current_users['inactive'] ?></h1>
								
                                </div>
                           
                        </div>
						
								
                           
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    require('inc/scripts.php');
    ?>
	<script src="scripts/dashboard.js"></script>
</body>
</html>
