<?php
require('admin/inc/db_config.php');
require('admin/inc/essentials.php');

$current_page_url = $_SERVER['HTTP_REFERER'];

//for logout



// Check if the user is trying to log out
if (isset($_POST['logout'])) {
    // Destroy the session and redirect to the login page
    session_start(); // Start the session (if not already started)
    session_destroy();
    header("Location: index.php");
    exit;
}

// Rest of your login and registration code goes here...

//for login 

if(isset($_POST['login']))
{
	$query="SELECT * FROM `registration` WHERE `email` = '$_POST[email_or_phone]' OR `phonenum` = '$_POST[email_or_phone]'";
	$result=mysqli_query($con,$query);
	
	if($result)
	{
		if(mysqli_num_rows($result)==1)
		{
		  $result_fetch= mysqli_fetch_assoc($result);	
		  if(password_verify($_POST['pass'],$result_fetch['password']))// function will match login model password and hashed password
		  {
			if($result_fetch['status']==0){
				echo "
				<script>
				alert('inactive');
				 window.location.href='index.php';
				</script>";
			}
			else{
				session_start();
				//$session[new variables] = [fields of database]
				$_SESSION['login'] = true;
				$_SESSION['uId']= $result_fetch['id'];
				$_SESSION['uName']= $result_fetch['name'];
				$_SESSION['uPhone']=$result_fetch['phonenum'];
				echo 1;
				
				
				 
				   // Redirect the user to the previously determined page URL
        header("Location: $current_page_url");
        exit;
				
			}
				
		  } 
			else
			{ // if incorrect password 
				echo "
				
				<script>
				alert('incorrect password!');
				window.location.href='index.php';
				</script>";	
			}
		  
		}
		else
		{
			echo "
			<script>
			alert('Email or user not registered!');
			window.location.href='index.php';
			</script>";	
		}
	}
	else
	{
		echo "
        <script>
        alert('can not login!');
        window.location.href='index.php';
        </script>";
	}


}


# for registration
if (isset($_POST['register']))
{
	$phonenum = $_POST['phonenum'];
    $email = $_POST['email'];
	
	if($_POST['pass'] != $_POST['cpass'])
	{
		echo "
                <script>
                alert('password and confirm pass mismatch');
                window.location.href='index.php';
                </script>";
				exit;
	}
	
	$user_exist_query ="SELECT * FROM `registration` WHERE `phonenum` = '$_POST[phonenum]' OR `email` ='$_POST[email]'  ";
	$result=mysqli_query($con,$user_exist_query);
	
	if($result)
	{
		
		if(mysqli_num_rows($result)>0)#if any email or phone number already registered
		{
			$result_fetch = mysqli_fetch_assoc($result);
			if ($result_fetch['email'] == $_POST['email'])
			{
				#error for email already registered
                echo "
                <script>
                alert('$result_fetch[email] Email already registered');
                window.location.href='index.php';
                </script>";
            } 
			else 
			{
				#error for phone number already registered
                echo "
                <script>
                alert('$result_fetch[phonenum] Phone number  already registered');
                window.location.href='index.php';
                </script>";
            }
		}
		
		
		
			
		else #if phonenum and email not in use
		{
			
			$password = password_hash($_POST['pass'], PASSWORD_BCRYPT); // password hash

			
			// Prepare the SQL statement with placeholders
			$query = "INSERT INTO `registration`(`name`, `email`, `phonenum`, `gender`, `address`, `pincode`, `dob`, `password`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

			if ($stmt = mysqli_prepare($con, $query)) 
			{// Bind the parameters
				
				mysqli_stmt_bind_param($stmt, "ssssssss", $_POST['name'], $_POST['email'], $_POST['phonenum'], $_POST['gender'], $_POST['address'], $_POST['pincode'], $_POST['dob'], $password);

				// Execute the prepared statement
				
					if (mysqli_stmt_execute($stmt))
					{				
						// Data inserted successfully
						echo "
						<script>
						alert('Successfully registered');
						window.location.href='index.php';
						</script>";
					}
					else 
					{
						// If data not inserted
						echo "
						<script>
						alert('Server Down!');
						window.location.href='index.php';
						</script>";
					}

				// Close the prepared statement
				mysqli_stmt_close($stmt);
			}
			
			else 
			{
				// Error in preparing the statement
				echo "
				<script>
				alert('Server Error: Unable to register');
				window.location.href='index.php';
				</script>";
			}


		}
	}
}	

	
?>