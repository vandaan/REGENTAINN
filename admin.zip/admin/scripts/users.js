	function get_users()
		{
			let xhr = new XMLHttpRequest();
	    	xhr.open("POST","ajax/users.php",true);
			xhr.setRequestHeader('Content-type','application/x-www-form-urlencoded');

		
	       xhr.onload=function()
			{
			  document.getElementById('users-data').innerHTML= this.responseText;
			}
		xhr.send('get_users');
		}
		
		
		function toggle_status(id, val) {
    console.log("id:", id);
    console.log("val:", val);

    let xhr = new XMLHttpRequest();
    xhr.open("POST", "ajax/users.php", true);
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

    xhr.onload = function () {
        console.log("Response:", this.responseText); // Log the response from the server

        if (this.responseText.trim() === '1') {
            alert('success',' Status toggled !');
            get_users();
        } else {
            alert('error',' Server Down or Status Not Updated. Check the console for details.'); // Show an error message to the user
        }
    }

    xhr.onerror = function () {
        console.error("Request failed. Check the console for details."); // Log any network errors
        alert('Error: Request failed. Check the console for details.');
    }

    xhr.send('toggle_status=' + id + '&value=' + val);
}
	
		 function remove_user(user_id)
		{
		  if(confirm("Are you sure, you want to remove this user?"))
			{
			  let data = new FormData();
			  data.append('user_id',user_id);
			  data.append('remove_user','');
			  
			  let xhr = new XMLHttpRequest();
			  xhr.open("POST", "ajax/users.php", true);
	
		
		xhr.onload=function(){
			
			if(this.responseText == 1)
			{
				alert('success','User removed!');
				get_users();
			}
			else
			{
				alert('error','User removal failed!');
			}
			
		};
		xhr.send(data);
			}
			
		  
		} 
		
		//search funtion
		
		function search_user(username)
		{
		let xhr = new XMLHttpRequest();
	    	xhr.open("POST","ajax/users.php",true);
			xhr.setRequestHeader('Content-type','application/x-www-form-urlencoded');

		
	       xhr.onload=function()
			{
			  document.getElementById('users-data').innerHTML= this.responseText;
			}
		xhr.send('search_user&name='+username);	
		}
		
		window.onload= function()
		{
			get_users();
		}