<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Regenta Inn Hotel - PROFILE</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
<meta name="viewport" content="width=device-width, initial-scale=1">
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

         <?php 
		 
		 require('inc/header.php');
		 
		 if(!(isset($_SESSION['login']) && $_SESSION['login'] == true))
			{
				redirect('index.php');
			}
			
			$u_exist = select("SELECT * FROM `registration` WHERE `id`=? LIMIT 1",[$_SESSION['uId']],'s');
			
			if(mysqli_num_rows($u_exist)==0)
			{
				redirect('index.php');
			}
			$u_fetch = mysqli_fetch_assoc($u_exist);

		 ?>
		
		
		
        <!-- Page Header Start -->
        <div class="container-fluid page-header mb-5 p-0" style="background-image: url(images/carousel/IMG_91648.jpg); max-width: 1500px;" >
            <div class="container-fluid page-header-inner py-5">
                <div class="container text-center pb-5">
                    <h1 class="display-3 text-white mb-3 animated slideInDown">Profile</h1>
                    <nav aria-label="breadcrumb">
                       
                    </nav>
                </div>
            </div>
        </div>
        <!-- Page Header End -->

<?php
$selectedGender = $u_fetch['gender'];
?>
       

       
		
        <div class="container">
			<div class="row">
			
			<div class="col-12 my-5 px-4 ">
			<h2 class="fw-bold">PROFILE</h2>
			<div style="font-size: 14px;">
			<a href="index.php" class="text-secondary text-decoration-none">HOME</a>
			<span class="text-secondary"> > </span>
			<a href="#" class="text-secondary text-decoration-none">PROFILE</a>
			</div>
			</div>
				
			<div class="col-12 mb-5 px-4">
    <div class="bg-white p-3 p-md-4 rounded shadow-sm">
        <form id="info-form">
            <h5 class="mb-4 fw-bold">BASIC DETAILS</h5>
            <div class="row mb-3">
                <div class="col-md-6">
                    <label class="form-label">Name</label>
                    <input type="text" name="name" value="<?php echo $u_fetch['name']?>" class="form-control shadow-none">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Pincode</label>
                    <input type="number" name="pincode" value="<?php echo $u_fetch['pincode']?>" class="form-control shadow-none">
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-6">
                    <label class="form-label">Date of birth</label>
                    <input type="date" name="dob" value="<?php echo $u_fetch['dob']?>" class="form-control shadow-none">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Gender</label>
                    <select name="gender" class="form-select shadow-none">
                        <option value="" disabled selected>Select Gender</option>
                        <option value="male" <?php if ($selectedGender === 'male') echo 'selected'; ?>>Male</option>
                        <option value="female" <?php if ($selectedGender === 'female') echo 'selected'; ?>>Female</option>
                        <option value="other" <?php if ($selectedGender === 'other') echo 'selected'; ?>>Other</option>
                    </select>
                </div>
            </div>
            
            <div class="mb-4">
                <label class="form-label">Address</label>
                <textarea name="address" class="form-control shadow-none" rows="3"><?php  echo $u_fetch['address'] ?></textarea>
            </div>
            <button type="submit" name="register" class="btn btn-dark text-white custom-bg shadow-none">SAVE CHANGES</button>
        </form>
    </div>
</div>

		</div>
		</div>
		

		
		

        <!-- Footer Start -->
        <?php require('inc/footer.php') ?>
        <!-- Footer End -->
		
        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
	
	<script>
	document.addEventListener('DOMContentLoaded', function () {
    let info_form = document.getElementById('info-form');

    info_form.addEventListener('submit', function (e) {
        e.preventDefault();

        let data = new FormData();
        data.append('info_form', '');
        data.append('name', info_form.elements['name'].value);
        
        data.append('address', info_form.elements['address'].value);
        data.append('pincode', info_form.elements['pincode'].value);
        data.append('dob', info_form.elements['dob'].value);
        data.append('gender', info_form.elements['gender'].value);

        let xhr = new XMLHttpRequest();
        xhr.open("POST", "ajax/profile.php", true);

        xhr.onload = function () {
            if (this.responseText == 0) {
                alert("Updation failed!");
            } else {
                alert("Changes saved!");
                window.location.href = window.location.pathname;
            }
        }
        xhr.send(data);
    });
});

	</script>
</body>

</html>

