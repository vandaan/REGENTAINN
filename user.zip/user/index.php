
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Regenta Inn Hotel</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

        <!-- Header Start -->
         <?php require('inc/header.php');
		 ?>


        <!-- Carousel Start -->
        <div class="container-fluid p-0 mb-5">
            <div id="header-carousel" class="carousel slide" data-bs-ride="carousel">
               <div class="carousel-inner">
    <?php
    $res = selectAll('carousel');
    $firstItem = true; // To track the first item in the loop
    while ($row = mysqli_fetch_assoc($res)) {
        $path = CAROUSEL_IMAGE_PATH;
        $activeClass = $firstItem ? 'active' : ''; // Add active class only to the first item
        echo <<<data
        <div class="carousel-item $activeClass">
            <img class="w-100" src="$path$row[image]" alt="Image">
             <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                            <div class="p-3" style="max-width: 700px;">
                                <h6 class="section-title text-white text-uppercase mb-3 animated slideInDown">Luxury Living</h6>
                                <h1 class="display-3 text-white mb-4 animated slideInDown">Discover A Brand Luxurious Hotel</h1>
                                <a href="room.php" class="btn btn-primary py-md-3 px-md-5 me-3 animated slideInLeft">Our Rooms</a>
                                
                            </div>
                        </div>
        </div>
data;
        $firstItem = false; // Set to false after the first item is processed
    }
    ?>
</div>

                <button class="carousel-control-prev" type="button" data-bs-target="#header-carousel"
                    data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#header-carousel"
                    data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>
        <!-- Carousel End -->





        <!-- About Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6">
                        <h6 class="section-title text-start text-primary text-uppercase">About Us</h6>
                        <h1 class="mb-4">Welcome to <span class="text-primary text-uppercase">Hotel Regenta Inn </h1>
                        <p class="mb-4"> <?php echo $settings_r['site_about']?></p>
                        <div class="row g-3 pb-4">
                            <div class="col-sm-4 wow fadeIn" data-wow-delay="0.1s">
                                <div class="border rounded p-1">
                                    <div class="border rounded text-center p-4">
                                        <i class="fa fa-hotel fa-2x text-primary mb-2"></i>
                                        <h2 class="mb-1" data-toggle="counter-up">600</h2>
                                        <p class="mb-0">Rooms</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 wow fadeIn" data-wow-delay="0.3s">
                                <div class="border rounded p-1">
                                    <div class="border rounded text-center p-4">
                                        <i class="fa fa-users-cog fa-2x text-primary mb-2"></i>
                                        <h2 class="mb-1" data-toggle="counter-up">850</h2>
                                        <p class="mb-0">Staffs</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 wow fadeIn" data-wow-delay="0.5s">
                                <div class="border rounded p-1">
                                    <div class="border rounded text-center p-4">
                                        <i class="fa fa-users fa-2x text-primary mb-2"></i>
                                        <h2 class="mb-1" data-toggle="counter-up">1500</h2>
                                        <p class="mb-0">Clients</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                    <div class="col-lg-6">
                        <div class="row g-3">
                            <div class="col-6 text-end">
                                <img class="img-fluid rounded w-75 wow zoomIn" data-wow-delay="0.1s" src="images/about/about-1.jpg" style="margin-top: 25%;">
                            </div>
                            <div class="col-6 text-start">
                                <img class="img-fluid rounded w-100 wow zoomIn" data-wow-delay="0.3s" src="images/about/about-2.jpg">
                            </div>
                            <div class="col-6 text-end">
                                <img class="img-fluid rounded w-50 wow zoomIn" data-wow-delay="0.5s" src="images/about/about-3.jpg">
                            </div>
                            <div class="col-6 text-start">
                                <img class="img-fluid rounded w-75 wow zoomIn" data-wow-delay="0.7s" src="images/about/about-4.jpg">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About End -->


        <!-- Room Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                    <h6 class="section-title text-center text-primary text-uppercase">Our Rooms</h6>
                    <h1 class="mb-5">Explore Our <span class="text-primary text-uppercase">Rooms</span></h1>
                </div>
                <div class="row g-4">
				
				
				 
				<?php
$room_res = select("SELECT * FROM `rooms` WHERE `status`=? AND `removed`=? ORDER BY `id`DESC LIMIT 3", [1, 0], 'ii');

while ($room_data = mysqli_fetch_assoc($room_res)) {
    //get features of Room
    $fea_q = mysqli_query($con,"SELECT f.name FROM `features` f INNER JOIN `room_features` rfea ON f.id = rfea.features_id WHERE rfea.room_id= '$room_data[id]'");

    $features_data = "";
    while ($fea_row = mysqli_fetch_assoc($fea_q)) {
        $features_data .= "<span class='badge rounded-pill bg-light text-dark text-wrap me-1 mb-1'>
                            $fea_row[name]
                            </span>";
    }

    //get facilities of Room
    $fac_q = mysqli_query($con,"SELECT f.name FROM `facilities` f INNER JOIN `room_facilities` rfac ON f.id=rfac.facilities_id WHERE rfac.room_id= '$room_data[id]'");

    $facilities_data = "";
    while ($fac_row = mysqli_fetch_assoc($fac_q)) {
        $facilities_data .= "<span class='badge rounded-pill bg-light text-dark text-wrap me-1 mb-1'>
                            $fac_row[name]
                            </span>";
    }
	$book_btn = "";

if (!$settings_r['shutdown']) {
	$login=0;
	
	if (isset($_SESSION['login']) && $_SESSION['login'] == true) 
	{
	$login=1;	
	}
	
    $book_btn = "<button onclick=\"checkLoginToBook($login, {$room_data['id']})\" class='btn btn-sm btn-dark rounded py-2 px-4'>Book Now</button>";
}

    //get thumbnail of image
    $room_thumb = ROOMS_IMAGE_PATH."thumbnail.jpg";
    $thumb_q = mysqli_query($con,"SELECT * FROM `room_images` WHERE `room_id`='$room_data[id]' AND `thumb`='1'");

    if (mysqli_num_rows($thumb_q) > 0) {
        $thumb_res = mysqli_fetch_assoc($thumb_q);
        $room_thumb = ROOMS_IMAGE_PATH.$thumb_res['image'];
    }

    //print room card
    echo<<<data
    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
        <div class="room-item shadow rounded overflow-hidden">
            <div class="position-relative">
                <img class="img-fluid" src="$room_thumb" alt="">
                <small class="position-absolute start-0 top-100 translate-middle-y bg-primary text-white rounded py-1 px-3 ms-4">$room_data[price]/Night</small>
            </div>
            <div class="p-4 mt-2">
                <div class="d-flex justify-content-between mb-3">
                    <h5 class="mb-0">$room_data[name]</h5>
                </div>
                <div class="features mb-3">
                    <h6 class="mb-3">Features</h6>
                    $features_data
                </div>
                <div class="facilities mb-3">
                    <h6 class="mb-3">Facilities</h6>
                    $facilities_data
                </div>
                <div class="d-flex justify-content-between">
                    $book_btn
					<a href="room_details.php?id=$room_data[id]" class="btn btn-sm  w-40 btn-outline-dark rounded py-2 shadow-none" >More details</a>
                </div>
            </div>
        </div>
    </div>
data;
}
?>
					<div class="col-log-12 text-center mt-5">
					<a href="room.php"class="btn btn-outline-dark rounded-0 fw-bold shadow-none text-center wow fadeInUp" data-wow-delay="0.1s">MORE ROOMS>>></a>
					</div>
					
                </div>
            </div>
        </div>
        <!-- Room End -->


       

        <!-- Service Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                    <h6 class="section-title text-center text-primary text-uppercase">Our Services</h6>
                    <h1 class="mb-5">Explore Our <span class="text-primary text-uppercase">Services</span></h1>
                </div>
                
                    
					 <div class="container">
					 <div class="row justify-content-evenly px-lg-0 px-5 mb-5 ">
					<?php
					
					$res= mysqli_query($con,"SELECT * FROM `facilities` ORDER BY `id` DESC  LIMIT 3");
					$path=FACILITIES_IMAGE_PATH;
					
					
					while ($row = mysqli_fetch_assoc($res))
					{
						echo <<<data
						<div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
							<a class="service-item rounded" href="">
								<div class="service-icon bg-yellow border rounded p-1">
									<div class="w-100 h-100 border rounded d-flex align-items-center justify-content-center">
										<img src="{$path}{$row['icon']}" width="60" height="60"  alt="Service Icon" class="text-primary">
									</div>
								</div>
								<h5 class="mb-3">{$row['name']}</h5>
								
							</a>
						</div>
					data;
					}
			?>
			</div>
		</div>
				<div class="col-log-12 text-center mt-5">
					<a href="service.php"class="btn btn-outline-dark rounded-0 fw-bold shadow-none text-center wow fadeInUp" data-wow-delay="0.1s">MORE SERVICES>>></a>
					
					</div>
					
            </div>
        </div>
        <!-- Service End -->


       

       

         

        <?php require('inc/footer.php'); ?>

        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
	<!-- Your HTML content here -->

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const form = document.querySelector('form[name="registration-form"]');

        form.addEventListener('submit', function (event) {
            const nameInput = form.querySelector('input[name="name"]');
            const phoneInput = form.querySelector('input[name="phonenum"]');
            const pincodeInput = form.querySelector('input[name="pincode"]');
            
            let isValid = true;

            // Name validation
            if (!/^[A-Za-z\s]+$/.test(nameInput.value)) {
                alert('Please enter a valid name .');
                isValid = false;
            }

            // Phone number validation
            if (!/^\d{10}$/.test(phoneInput.value)) {
                alert('Please enter a valid 10-digit phone number.');
                isValid = false;
            }

            // Pincode validation
            if (!/^\d{6}$/.test(pincodeInput.value)) {
                alert('Please enter a valid 6-digit pincode.');
                isValid = false;
            }

            if (!isValid) {
                event.preventDefault(); // Prevent form submission
            }
        });
    });
</script>

<!-- Rest of your HTML content -->

	
</body>

</html>