<?php

require('../admin/inc/db_config.php');
require('../admin/inc/essentials.php');

date_default_timezone_set("Asia/Kolkata"); 

if (isset($_POST['check_availability'])) {
    $frm_data = filteration($_POST);
    $status = "";
    $result = "";

    // Check-in and check-out validations
    $today_date = new DateTime(date("y-m-d"));
    $checkin_date = new DateTime($frm_data['check_in']);
    $checkout_date = new DateTime($frm_data['check_out']);

    if ($checkin_date == $checkout_date) {
        $status = 'check_in_out_equal';
    } else if ($checkout_date < $checkin_date) {
        $status = 'check_out_earlier';
    } else if ($checkin_date < $today_date) {
        $status = 'check_in_earlier';
    }

    // Check booking availability if status is blank else return the error
    if ($status != '') {
        $result = json_encode(["status" => $status]);
    } else {
        session_start();

        // Run query to check if the room is already booked for the same dates
        $check_existing_booking_query = "SELECT COUNT(*) AS `existing_bookings` FROM `booking_order`
                                         WHERE room_id = ? 
                                         AND check_out > ? 
                                         AND check_in < ?";
        $values = [$_SESSION['room']['id'], $frm_data['check_in'], $frm_data['check_out']];
        $existing_booking_fetch = mysqli_fetch_assoc(select($check_existing_booking_query, $values, 'iss'));

        if ($existing_booking_fetch['existing_bookings'] > 0) {
            // There is already a booking for this room with overlapping dates
            $status = "duplicate_booking";
            $result = json_encode(["status" => $status]);
        }else {
            // No overlapping bookings found, the room is available
            $status = "available";
        }

        $count_days = date_diff($checkin_date, $checkout_date)->days;

        // Assuming $_SESSION['room']['price'] contains the price per day
        $price_per_day = $_SESSION['room']['price'];
        $payment = $count_days * $price_per_day;

        $_SESSION['room']['payment'] = $payment;
        $_SESSION['room']['available'] = true;

        $result = json_encode(["status" => 'available', "days" => $count_days, "payment" => $payment]);
    }

    // Send the JSON response
    header('Content-Type: application/json');
    echo $result;
}
?>
