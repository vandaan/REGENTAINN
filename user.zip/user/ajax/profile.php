<?php
// Start the session if not already started
session_start();

require('../admin/inc/db_config.php');
require('../admin/inc/essentials.php');

date_default_timezone_set("Asia/Kolkata"); 

if(isset($_POST['info_form']))
{
    $frm_data = filteration($_POST);

   
    $query = "UPDATE `registration` SET `name`=?, `gender`=?, `address`=?, `pincode`=?, `dob`=? WHERE `id`=? LIMIT 1";
    $values = [$frm_data['name'],  $frm_data['gender'], $frm_data['address'], $frm_data['pincode'], $frm_data['dob'], $_SESSION['uId']];

    if(update($query, $values, 'ssssss')) {
        $_SESSION['uName'] = $frm_data['name'];
        echo 1; 
    }
    else {
        echo 0;
    }
}
?>
