
 
 
 

<!-- Footer Start -->
        <div class="container-fluid bg-dark mt-5 text-light footer wow fadeIn" data-wow-delay="0.1s">
            <div class="container pb-5">
                <div class="row g-5">
                    <div class="col-md-6 col-lg-4">
                        <div class="bg-primary rounded p-4">
                            <a href="index.php"><h1 class="text-white text-uppercase mb-3"><?php  echo $settings_r['site_title']?></h1></a>
                            <p class="text-white mb-0">
								 <img class="w-100" src="images/carousel/IMG_91648.jpg" alt="Image">
							</p>

                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <h6 class="section-title text-start text-primary text-uppercase mb-4">Contact</h6>
                        <a href="<?php echo $contact_r['gmap'] ?>" target="_blank" class="d-inline-block text-decoration-none text-white mb-2" >
						   <i class="bi bi-geo-alt-fill"></i>
                          <?php echo $contact_r['address'] ?>
						   </a>
						   
                        
                       <i class="fa fa-envelope text-primary me-2"></i>
                                <a class="me-3 d-inline-block text-decoration-none text-white" href="<?php echo $contact_r['email'] ?>"> <?php echo $contact_r['email'] ?></a>
                        
                    </div>
                    <div class="col-lg-5 col-md-12">
                        <div class="row gy-5 g-4">
                            <div class="col-md-6">
                                <h6 class="section-title text-start text-primary text-uppercase mb-4">Company</h6>
								<a class="btn btn-link" href="index.php">Home</a>
                                <a class="btn btn-link" href="about.php">About us</a>
								<a class="btn btn-link" href="service.php">Services</a>
								<a class="btn btn-link" href="room.php">Rooms</a>
                                <a class="btn btn-link" href="contact.php">Contact Us</a>
                               
                            </div>
                            <div class="col-md-6">
                                <h6 class="section-title text-start text-primary text-uppercase mb-4">Services</h6>
                                <a class="btn btn-link" href="">Food & Restaurant</a>
                                <a class="btn btn-link" href="">Spa & Fitness</a>
                                <a class="btn btn-link" href="">Sports & Gaming</a>
                                <a class="btn btn-link" href="">Event & Party</a>
                                <a class="btn btn-link" href="">GYM & Yoga</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="copyright">
                    <div class="row">
                        <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                            &copy; <a class="border-bottom" href="#">Regenta Inn</a>, All Right Reserved. 
							
							
							Designed By VANDANA & SONIYA.
                        </div>
                        <div class="col-md-6 text-center text-md-end">
                            <div class="footer-menu">
                                <a href="index.php">Home</a>
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer End -->
		
		
		<!--activelinks-->
<script>
		function setActive()
		{
			let navbar = document.getElementById('nav-bar');
			let a_tags = navbar.getElementsByTagName('a');
			
			for(i=0; i<a_tags.length; i++){
			let file = a_tags[i].href.split('/').pop();
			let file_name = file.split('.')[0];
			
			if(document.location.href.indexOf(file_name) >= 0){
				a_tags[i].classList.add('active');
			}
			}
		}
		
		function checkLoginToBook(status,room_id)
		{
			if(status){
				window.location.href='confirm_booking.php?id='+room_id;
			}
			else
			{
				alert('Plese login to book room! ');
			}
		}
		setActive();
		</script>
	
