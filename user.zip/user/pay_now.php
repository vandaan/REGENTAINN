<?php
require('admin/inc/db_config.php');
require('admin/inc/essentials.php');

date_default_timezone_set("Asia/Kolkata");

session_start();

if (!(isset($_SESSION['login']) && $_SESSION['login'] == true)) {
    // Redirect the user to the login page or any other appropriate page
    header('Location: login.php'); // You can replace 'login.php' with the actual login page URL
    exit;
}

if (isset($_POST['pay_now'])) {
    // Insert data into the database
    $frm_data = filteration($_POST);

    $CUST_ID = $_SESSION['uId'];

    // Insert booking order data
    $query1 = "INSERT INTO `booking_order`(`user_id`, `room_id`, `check_in`, `check_out`) VALUES (?,?,?,?)";
    
    if (insert($query1, [$CUST_ID, $_SESSION['room']['id'], $frm_data['checkin'], $frm_data['checkout']], 'isss')) {
        $booking_id = mysqli_insert_id($con);

        // Insert booking details data
        $query2 = "INSERT INTO `booking_details`(`booking_id`, `room_name`, `price`,`total_pay` ,`user_name`, `phonenum`, `address`) VALUES (?,?,?,?,?,?,?)";

        if (insert($query2, [$booking_id, $_SESSION['room']['name'], $_SESSION['room']['price'], $_SESSION['room']['payment'], $frm_data['name'], $frm_data['phonenum'], $frm_data['address']], 'issssss')) {
            // Data insertion was successful
            $_SESSION['alert_message'] = '<div class="alert alert-success alert-dismissible fade show custom-alert" role="alert">
                <strong>' . $_SESSION['room']['name'] . ' room confirmed successfully. Please refer to the booking page.</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
        } else {
            // Error in inserting booking details
            $_SESSION['alert_message'] = '<div class="alert alert-danger alert-dismissible fade show custom-alert" role="alert">
                <strong>Error inserting booking details.</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
        }
    } else {
        // Error in inserting booking order
        $_SESSION['alert_message'] = '<div class="alert alert-danger alert-dismissible fade show custom-alert" role="alert">
            <strong>Error inserting booking order.</strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
    }
    
    // Redirect the user back to confirm_booking.php
    header('Location: confirm_booking.php');
    exit;
}
?>
