<?php
session_start(); // Start the session

// Check if the user is already logged out (optional)
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: index.php"); // Redirect to the login page
    exit;
}

// Check if the user is trying to log out
if (isset($_POST['logout'])) {
    // Destroy the session and redirect to the login page
    session_destroy();
    header("Location: index.php");
    exit;
}
?>
