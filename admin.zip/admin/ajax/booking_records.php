<?php

	require('../inc/db_config.php');   
	require('../inc/essentials.php');
	adminLogin();
	
	
	if (isset($_POST['get_bookings'])) {
		
		$frm_data = filteration($_POST);
		
		 $query = "SELECT bo.*, bd.* FROM `booking_order` bo
    INNER JOIN `booking_details` bd ON bo.booking_id = bd.booking_id
    WHERE bo.arrival = 1 AND (bd.phonenum LIKE ? OR bd.user_name LIKE ?)
    ORDER BY bo.booking_id DESC";
    
    $res = select($query, ["%$frm_data[search]%","%$frm_data[search]%"], 'ss');
   
	$i = 1;
    $table_data = "";
		
		if(mysqli_num_rows($res)==0){
			echo "<br> NO DATA FOUND!</br>";
			exit;
		}
		
		while($data = mysqli_fetch_assoc($res))
		{
			$date = date("d-m-Y",strtotime($data['datentime']));
			$checkin = date("d-m-Y",strtotime($data['check_in']));
			$checkout = date("d-m-Y",strtotime($data['check_out']));
			$table_data .= "
			<tr>
			<td>$i</td>
			<td>
			<br>
			<b> Name: </b> $data[user_name]
			<br>
			<b> Phone number: </b> $data[phonenum]
			</td>
			<td>
				<b> Room: </b> $data[room_name]
				<br>
				<b>Price: </b> Rs.$data[price]
			</td>
			<td>
				<b>Check in:</b> $checkin
				<br>
				<b>Check out:</b> $checkout
				<br>
				<b>Total amount to pay </b> Rs. $data[total_pay]
				<br>
				<b>Date:</b> $date
			</td>

			</tr>";
			
			$i++;
		}
   echo $table_data;
}
	
	
?>


