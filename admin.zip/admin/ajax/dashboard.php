<?php
require('../inc/db_config.php');
require('../inc/essentials.php');
adminLogin();

if (isset($_POST['booking_analytics'])) {
    $frm_data = filteration($_POST);
    $result = mysqli_fetch_assoc(mysqli_query($con, "SELECT 
        COUNT(booking_id) AS `total_bookings`,
        COUNT(CASE WHEN arrival = 1 THEN 1 END) AS `active_bookings` FROM `booking_order`"));
    
    $output = json_encode($result);
    echo $output;
}

if (isset($_POST['user_analytics'])) {
    $total_queries = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(sr_no) AS `count` FROM `user_queries` WHERE `seen` = 0"));
    $total_new_reg = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(id) AS `count` FROM `registration`"));

    $output = [
        'total_queries' => $total_queries['count'],
        'total_new_reg' => $total_new_reg['count']
    ];
    
    $output = json_encode($output);
    echo $output;
}
?>
